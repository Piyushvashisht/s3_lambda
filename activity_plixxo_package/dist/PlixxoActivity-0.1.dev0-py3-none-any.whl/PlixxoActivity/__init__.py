try:
    from activity import activity
except ImportError:
    from .activity import activity
name = "project"